CREATE DATABASE IF NOT EXISTS db_paqueteria
  CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE db_paqueteria;

CREATE TABLE ciudad (
  idCiudad INT AUTO_INCREMENT PRIMARY KEY,
  nombre   VARCHAR(60) NOT NULL UNIQUE
);

CREATE TABLE camionero (
  idCamionero INT AUTO_INCREMENT PRIMARY KEY,
  nombre      VARCHAR(50)   NOT NULL,
  apellidos   VARCHAR(60)   NOT NULL,
  direccion   VARCHAR(120)  NOT NULL,
  salario     DECIMAL(10,2) NOT NULL CHECK (salario > 0),
  poblacion   VARCHAR(60)   NOT NULL,
  dpi         CHAR(13)      NOT NULL UNIQUE,
  telefono    CHAR(8)       NOT NULL
);

CREATE TABLE camion (
  idCamion INT AUTO_INCREMENT PRIMARY KEY,
  modelo   VARCHAR(50)   NOT NULL,
  tipo     VARCHAR(40)   NOT NULL,
  potencia DECIMAL(8,2)  NOT NULL CHECK (potencia > 0),
  noPlaca  VARCHAR(10)   NOT NULL UNIQUE
);

CREATE TABLE conductor_camion (
  idConductorCamion INT AUTO_INCREMENT PRIMARY KEY,
  idCamionero       INT  NOT NULL,
  idCamion          INT  NOT NULL,
  fecha             DATE NOT NULL,
  CONSTRAINT fk_cc_camionero FOREIGN KEY (idCamionero) REFERENCES camionero(idCamionero),
  CONSTRAINT fk_cc_camion    FOREIGN KEY (idCamion)    REFERENCES camion(idCamion),
  CONSTRAINT uq_cc UNIQUE (idCamionero, idCamion, fecha)
);

CREATE TABLE paquete (
  idPaquete   INT AUTO_INCREMENT PRIMARY KEY,
  descripcion VARCHAR(150)  NOT NULL,
  destinatario VARCHAR(100) NOT NULL,
  peso        DECIMAL(8,2)  NOT NULL CHECK (peso > 0),
  direccion   VARCHAR(120)  NOT NULL,
  idCamionero INT NOT NULL,
  idCiudad    INT NOT NULL,
  CONSTRAINT fk_paq_camionero FOREIGN KEY (idCamionero) REFERENCES camionero(idCamionero),
  CONSTRAINT fk_paq_ciudad    FOREIGN KEY (idCiudad)    REFERENCES ciudad(idCiudad)
);

INSERT INTO ciudad (nombre) VALUES
 ('Guatemala'), ('Quetzaltenango'), ('Antigua Guatemala'), ('Escuintla'), ('Cobán');
 
 