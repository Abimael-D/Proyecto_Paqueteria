/**
 *
 * @author Hermelindo.UMG
 */
package main;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Camionero;
import modelo.Ciudad;
import modelo.Paquete;

public class MenuPaquete {
    static Scanner sc = new Scanner(System.in);

   public static void ejecutar() {
        int op;
        do {
            System.out.println("\n=== CRUD PAQUETE ===");
            System.out.println("1. Insertar\n2. Listar\n3. Buscar por ID\n4. Actualizar\n5. Eliminar\n0. Salir");
            System.out.print("Opción: ");
            op = leerEntero();
            try {
                switch (op) {
                    case 1: insertar(); break;
                    case 2: Paquete.listar().forEach(System.out::println); break;
                    case 3: buscar(); break;
                    case 4: actualizar(); break;
                    case 5: eliminar(); break;
                    case 0: System.out.println("Hasta luego."); break;
                    default: System.out.println("Opción no válida.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Validación: " + e.getMessage());
            } catch (SQLException e) {
                System.out.println("Error de base de datos: " + e.getMessage());
            }
        } while (op != 0);
    }

    static void insertar() throws SQLException {
        Paquete p = pedirDatos(new Paquete());
        p.insertar();
        System.out.println("Paquete insertado con ID " + p.getIdPaquete());
    }

    static void buscar() throws SQLException {
        System.out.print("ID: ");
        Paquete p = Paquete.buscarPorId(leerEntero());
        System.out.println(p != null ? p : "No se encontró el paquete.");
    }

    static void actualizar() throws SQLException {
        System.out.print("ID a actualizar: ");
        Paquete p = Paquete.buscarPorId(leerEntero());
        if (p == null) { System.out.println("No se encontró el paquete."); return; }
        pedirDatos(p).actualizar();
        System.out.println("Paquete actualizado.");
    }

    static void eliminar() throws SQLException {
        System.out.print("ID a eliminar: ");
        Paquete p = Paquete.buscarPorId(leerEntero());
        if (p == null) { System.out.println("No se encontró el paquete."); return; }
        p.eliminar();
        System.out.println("Paquete eliminado.");
    }

    static Paquete pedirDatos(Paquete p) throws SQLException {
        System.out.print("Descripción: ");  p.setDescripcion(sc.nextLine());
        System.out.print("Destinatario: "); p.setDestinatario(sc.nextLine());
        System.out.print("Peso (kg): ");
        try {
            p.setPeso(new BigDecimal(sc.nextLine().trim()));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("El peso debe ser un número.");
        }
        System.out.print("Dirección de entrega: "); p.setDireccion(sc.nextLine());

        System.out.println("--- Camioneros disponibles ---");
        Camionero.listar().forEach(System.out::println);
        System.out.print("ID del camionero: ");
        p.setCamionero(Camionero.buscarPorId(leerEntero()));

        System.out.println("--- Ciudades disponibles ---");
        Ciudad.listar().forEach(System.out::println);
        System.out.print("ID de la ciudad destino: ");
        p.setCiudad(Ciudad.buscarPorId(leerEntero()));
        return p;
    }

    static int leerEntero() {
        try {
            return Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}