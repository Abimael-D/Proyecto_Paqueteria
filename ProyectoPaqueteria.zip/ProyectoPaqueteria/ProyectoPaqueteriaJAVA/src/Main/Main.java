/**
 *
 * @author Hermelindo.UMG
 */


package main;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int op;
        do {
            System.out.println("\n===== SISTEMA DE PAQUETERIA =====");
            System.out.println("1. Camionero");
            System.out.println("2. Camión");
            System.out.println("3. Paquete");
            System.out.println("4. Camionero - Camión (asignaciones)");
            System.out.println("0. Salir");
            System.out.print("Opción: ");
            try {
                op = Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                op = -1;
            }
            switch (op) {
                case 1: MenuCamionero.ejecutar(); break;
                case 2: MenuCamion.ejecutar(); break;
                case 3: MenuPaquete.ejecutar(); break;
                case 4: MenuConductorCamion.ejecutar(); break;
                case 0: System.out.println("Programa finalizado."); break;
                default: System.out.println("Opción no válida.");
            }
        } while (op != 0);
    }
}