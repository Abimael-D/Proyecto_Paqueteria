package main;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Camionero;

public class MenuCamionero {
    static Scanner sc = new Scanner(System.in);

    public static void ejecutar() {
        int op;
        do {
            System.out.println("\n=== CRUD CAMIONERO ===");
            System.out.println("1. Insertar\n2. Listar\n3. Buscar por ID\n4. Actualizar\n5. Eliminar\n0. Salir");
            System.out.print("Opción: ");
            op = leerEntero();
            try {
                switch (op) {
                    case 1: insertar(); break;
                    case 2: Camionero.listar().forEach(System.out::println); break;
                    case 3: buscar(); break;
                    case 4: actualizar(); break;
                    case 5: eliminar(); break;
                    case 0: System.out.println("Hasta luego."); break;
                    default: System.out.println("Opción no válida.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Validación: " + e.getMessage());
            } catch (SQLException e) {
                System.out.println("Error de base de datos: " + e.getMessage());
            }
        } while (op != 0);
    }

    static void insertar() throws SQLException {
        Camionero c = pedirDatos(new Camionero());
        c.insertar();
        System.out.println("Camionero insertado con ID " + c.getIdCamionero());
    }

    static void buscar() throws SQLException {
        System.out.print("ID: ");
        Camionero c = Camionero.buscarPorId(leerEntero());
        System.out.println(c != null ? c : "No se encontró el camionero.");
    }

    static void actualizar() throws SQLException {
        System.out.print("ID a actualizar: ");
        Camionero c = Camionero.buscarPorId(leerEntero());
        if (c == null) { System.out.println("No se encontró el camionero."); return; }
        pedirDatos(c).actualizar();
        System.out.println("Camionero actualizado.");
    }

    static void eliminar() throws SQLException {
        System.out.print("ID a eliminar: ");
        Camionero c = Camionero.buscarPorId(leerEntero());
        if (c == null) { System.out.println("No se encontró el camionero."); return; }
        c.eliminar();
        System.out.println("Camionero eliminado.");
    }

    static Camionero pedirDatos(Camionero c) {
        System.out.print("Nombre: ");     c.setNombre(sc.nextLine());
        System.out.print("Apellidos: ");  c.setApellidos(sc.nextLine());
        System.out.print("Dirección: ");  c.setDireccion(sc.nextLine());
        System.out.print("Salario: ");
        try {
            c.setSalario(new BigDecimal(sc.nextLine().trim()));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("El salario debe ser un número.");
        }
        System.out.print("Población: ");  c.setPoblacion(sc.nextLine());
        System.out.print("DPI (13 dígitos): ");  c.setDpi(sc.nextLine().trim());
        System.out.print("Teléfono (8 dígitos): "); c.setTelefono(sc.nextLine().trim());
        return c;
    }

    static int leerEntero() {
        try {
            return Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}