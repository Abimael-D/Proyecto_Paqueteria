/**
 *
 * @author Hermelindo.UMG
 */
package main;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Scanner;
import modelo.Camion;

public class MenuCamion {
    static Scanner sc = new Scanner(System.in);

    public static void ejecutar() {
        int op;
        do {
            System.out.println("\n=== CRUD CAMION ===");
            System.out.println("1. Insertar\n2. Listar\n3. Buscar por ID\n4. Actualizar\n5. Eliminar\n0. Salir");
            System.out.print("Opción: ");
            op = leerEntero();
            try {
                switch (op) {
                    case 1: insertar(); break;
                    case 2: Camion.listar().forEach(System.out::println); break;
                    case 3: buscar(); break;
                    case 4: actualizar(); break;
                    case 5: eliminar(); break;
                    case 0: System.out.println("Hasta luego."); break;
                    default: System.out.println("Opción no válida.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Validación: " + e.getMessage());
            } catch (SQLException e) {
                System.out.println("Error de base de datos: " + e.getMessage());
            }
        } while (op != 0);
    }

    static void insertar() throws SQLException {
        Camion c = pedirDatos(new Camion());
        c.insertar();
        System.out.println("Camión insertado con ID " + c.getIdCamion());
    }

    static void buscar() throws SQLException {
        System.out.print("ID: ");
        Camion c = Camion.buscarPorId(leerEntero());
        System.out.println(c != null ? c : "No se encontró el camión.");
    }

    static void actualizar() throws SQLException {
        System.out.print("ID a actualizar: ");
        Camion c = Camion.buscarPorId(leerEntero());
        if (c == null) { System.out.println("No se encontró el camión."); return; }
        pedirDatos(c).actualizar();
        System.out.println("Camión actualizado.");
    }

    static void eliminar() throws SQLException {
        System.out.print("ID a eliminar: ");
        Camion c = Camion.buscarPorId(leerEntero());
        if (c == null) { System.out.println("No se encontró el camión."); return; }
        c.eliminar();
        System.out.println("Camión eliminado.");
    }

    static Camion pedirDatos(Camion c) {
        System.out.print("Modelo: "); c.setModelo(sc.nextLine());
        System.out.print("Tipo: ");   c.setTipo(sc.nextLine());
        System.out.print("Potencia (HP): ");
        try {
            c.setPotencia(new BigDecimal(sc.nextLine().trim()));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("La potencia debe ser un número.");
        }
        System.out.print("Placa: ");  c.setNoPlaca(sc.nextLine().trim());
        return c;
    }

    static int leerEntero() {
        try {
            return Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}