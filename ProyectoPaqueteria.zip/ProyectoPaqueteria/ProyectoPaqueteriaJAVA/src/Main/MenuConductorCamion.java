/**
 *
 * @author Hermelindo.UMG
 */
package main;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
import modelo.Camion;
import modelo.Camionero;
import modelo.ConductorCamion;

public class MenuConductorCamion {
    static Scanner sc = new Scanner(System.in);
    
public static void ejecutar() {
        int op;
        do {
            System.out.println("\n=== CRUD CONDUCTOR - CAMION ===");
            System.out.println("1. Insertar\n2. Listar\n3. Buscar por ID\n4. Actualizar\n5. Eliminar\n0. Salir");
            System.out.print("Opción: ");
            op = leerEntero();
            try {
                switch (op) {
                    case 1: insertar(); break;
                    case 2: ConductorCamion.listar().forEach(System.out::println); break;
                    case 3: buscar(); break;
                    case 4: actualizar(); break;
                    case 5: eliminar(); break;
                    case 0: System.out.println("Hasta luego."); break;
                    default: System.out.println("Opción no válida.");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Validación: " + e.getMessage());
            } catch (SQLException e) {
                System.out.println("Error de base de datos: " + e.getMessage());
            }
        } while (op != 0);
    }

    static void insertar() throws SQLException {
        ConductorCamion cc = pedirDatos(new ConductorCamion());
        cc.insertar();
        System.out.println("Asignación insertada con ID " + cc.getIdConductorCamion());
    }

    static void buscar() throws SQLException {
        System.out.print("ID: ");
        ConductorCamion cc = ConductorCamion.buscarPorId(leerEntero());
        System.out.println(cc != null ? cc : "No se encontró la asignación.");
    }

    static void actualizar() throws SQLException {
        System.out.print("ID a actualizar: ");
        ConductorCamion cc = ConductorCamion.buscarPorId(leerEntero());
        if (cc == null) { System.out.println("No se encontró la asignación."); return; }
        pedirDatos(cc).actualizar();
        System.out.println("Asignación actualizada.");
    }

    static void eliminar() throws SQLException {
        System.out.print("ID a eliminar: ");
        ConductorCamion cc = ConductorCamion.buscarPorId(leerEntero());
        if (cc == null) { System.out.println("No se encontró la asignación."); return; }
        cc.eliminar();
        System.out.println("Asignación eliminada.");
    }

    static ConductorCamion pedirDatos(ConductorCamion cc) throws SQLException {
        System.out.println("--- Camioneros disponibles ---");
        Camionero.listar().forEach(System.out::println);
        System.out.print("ID del camionero: ");
        cc.setConductor(Camionero.buscarPorId(leerEntero()));

        System.out.println("--- Camiones disponibles ---");
        Camion.listar().forEach(System.out::println);
        System.out.print("ID del camión: ");
        cc.setCamion(Camion.buscarPorId(leerEntero()));

        System.out.print("Fecha (AAAA-MM-DD): ");
        try {
            cc.setFecha(LocalDate.parse(sc.nextLine().trim()));
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Fecha inválida. Use el formato AAAA-MM-DD, por ejemplo 2026-10-24.");
        }
        return cc;
    }

    static int leerEntero() {
        try {
            return Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}