

/**
 *
 * @author Hermelindo.UMG
 */

package util;

import java.math.BigDecimal;

public class Validaciones {
    public static boolean vacio(String s) {
        return s == null || s.trim().isEmpty();
    }
    public static boolean esDpi(String s) {
        return s != null && s.matches("\\d{13}");
    }
    public static boolean esTelefono(String s) {
        return s != null && s.matches("\\d{8}");
    }
    public static boolean mayorACero(BigDecimal n) {
        return n != null && n.compareTo(BigDecimal.ZERO) > 0;
    }
        public static boolean esPlaca(String s) {
        return s != null && s.matches("[A-Za-z0-9]{5,10}");
    }
}