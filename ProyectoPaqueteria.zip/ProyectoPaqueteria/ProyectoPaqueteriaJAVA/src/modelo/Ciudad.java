/**
 *
 * @author Hermelindo.UMG
 */
package modelo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import util.Conexion;

public class Ciudad {
    private int idCiudad;
    private String nombre;

    public Ciudad() {}

    public Ciudad(int idCiudad, String nombre) {
        this.idCiudad = idCiudad;
        this.nombre = nombre;
    }

    public int getIdCiudad() {
        return idCiudad;
    }

    public void setIdCiudad(int idCiudad) {
        this.idCiudad = idCiudad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    

    public static List<Ciudad> listar() throws SQLException {
        List<Ciudad> lista = new ArrayList<>();
        try (Connection cn = Conexion.getConexion();
             Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM ciudad ORDER BY idCiudad")) {
            while (rs.next()) lista.add(new Ciudad(rs.getInt("idCiudad"), rs.getString("nombre")));
        }
        return lista;
    }

    public static Ciudad buscarPorId(int id) throws SQLException {
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement("SELECT * FROM ciudad WHERE idCiudad=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? new Ciudad(rs.getInt("idCiudad"), rs.getString("nombre")) : null;
            }
        }
    }

    @Override
    public String toString() {
        return idCiudad + " | " + nombre;
    }
}