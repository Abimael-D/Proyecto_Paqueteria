/**
 *
 * @author Hermelindo.UMG
 */
package modelo;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import util.Conexion;
import util.Validaciones;

public class Paquete {
    private int idPaquete;
    private String descripcion;
    private String destinatario;
    private BigDecimal peso;
    private String direccion;
    private Camionero camionero;
    private Ciudad ciudad;

    public Paquete() {}

    public Paquete(int idPaquete, String descripcion, String destinatario, BigDecimal peso,
                   String direccion, Camionero camionero, Ciudad ciudad) {
        this.idPaquete = idPaquete;
        this.descripcion = descripcion;
        this.destinatario = destinatario;
        this.peso = peso;
        this.direccion = direccion;
        this.camionero = camionero;
        this.ciudad = ciudad;
    }

    //getters y setters

    public int getIdPaquete() {
        return idPaquete;
    }

    public void setIdPaquete(int idPaquete) {
        this.idPaquete = idPaquete;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDestinatario() {
        return destinatario;
    }

    public void setDestinatario(String destinatario) {
        this.destinatario = destinatario;
    }

    public BigDecimal getPeso() {
        return peso;
    }

    public void setPeso(BigDecimal peso) {
        this.peso = peso;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Camionero getCamionero() {
        return camionero;
    }

    public void setCamionero(Camionero camionero) {
        this.camionero = camionero;
    }

    public Ciudad getCiudad() {
        return ciudad;
    }

    public void setCiudad(Ciudad ciudad) {
        this.ciudad = ciudad;
    }
    
    
    // ---------- VALIDACIONES ----------
    private void validar() throws SQLException {
        if (Validaciones.vacio(descripcion))  throw new IllegalArgumentException("La descripción es obligatoria.");
        if (Validaciones.vacio(destinatario)) throw new IllegalArgumentException("El destinatario es obligatorio.");
        if (Validaciones.vacio(direccion))    throw new IllegalArgumentException("La dirección es obligatoria.");
        if (!Validaciones.mayorACero(peso))   throw new IllegalArgumentException("El peso debe ser mayor a 0.");
        if (camionero == null || Camionero.buscarPorId(camionero.getIdCamionero()) == null)
            throw new IllegalArgumentException("El camionero indicado no existe.");
        if (ciudad == null || Ciudad.buscarPorId(ciudad.getIdCiudad()) == null)
            throw new IllegalArgumentException("La ciudad indicada no existe.");
    }

    // ---------- CRUD ----------
    public void insertar() throws SQLException {
        validar();
        String sql = "INSERT INTO paquete (descripcion, destinatario, peso, direccion, idCamionero, idCiudad) "
                   + "VALUES (?,?,?,?,?,?)";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, descripcion);
            ps.setString(2, destinatario);
            ps.setBigDecimal(3, peso);
            ps.setString(4, direccion);
            ps.setInt(5, camionero.getIdCamionero());
            ps.setInt(6, ciudad.getIdCiudad());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) idPaquete = rs.getInt(1);
            }
        }
    }

    public void actualizar() throws SQLException {
        validar();
        String sql = "UPDATE paquete SET descripcion=?, destinatario=?, peso=?, direccion=?, "
                   + "idCamionero=?, idCiudad=? WHERE idPaquete=?";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, descripcion);
            ps.setString(2, destinatario);
            ps.setBigDecimal(3, peso);
            ps.setString(4, direccion);
            ps.setInt(5, camionero.getIdCamionero());
            ps.setInt(6, ciudad.getIdCiudad());
            ps.setInt(7, idPaquete);
            if (ps.executeUpdate() == 0)
                throw new IllegalArgumentException("No existe un paquete con ese ID.");
        }
    }

    public void eliminar() throws SQLException {
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement("DELETE FROM paquete WHERE idPaquete=?")) {
            ps.setInt(1, idPaquete);
            if (ps.executeUpdate() == 0)
                throw new IllegalArgumentException("No existe un paquete con ese ID.");
        }
    }

    public static List<Paquete> listar() throws SQLException {
        List<Paquete> lista = new ArrayList<>();
        try (Connection cn = Conexion.getConexion();
             Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM paquete ORDER BY idPaquete")) {
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    public static Paquete buscarPorId(int id) throws SQLException {
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement("SELECT * FROM paquete WHERE idPaquete=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    private static Paquete mapear(ResultSet rs) throws SQLException {
        return new Paquete(rs.getInt("idPaquete"), rs.getString("descripcion"),
                rs.getString("destinatario"), rs.getBigDecimal("peso"), rs.getString("direccion"),
                Camionero.buscarPorId(rs.getInt("idCamionero")),
                Ciudad.buscarPorId(rs.getInt("idCiudad")));
    }

    @Override
    public String toString() {
        return idPaquete + " | " + descripcion + " | Para: " + destinatario + " | " + peso + " kg | "
                + direccion + " | Camionero: " + (camionero != null ? camionero.getNombre() + " " + camionero.getApellidos() : "-")
                + " | Destino: " + (ciudad != null ? ciudad.getNombre() : "-");
    }
}