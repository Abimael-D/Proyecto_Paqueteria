/**
 *
 * @author Hermelindo.UMG
 */
package modelo;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import util.Conexion;

public class ConductorCamion {
    private int idConductorCamion;
    private Camionero conductor;
    private Camion camion;
    private LocalDate fecha;

    public ConductorCamion() {}

    public ConductorCamion(int idConductorCamion, Camionero conductor, Camion camion, LocalDate fecha) {
        this.idConductorCamion = idConductorCamion;
        this.conductor = conductor;
        this.camion = camion;
        this.fecha = fecha;
    }
    //getters y setters

    public int getIdConductorCamion() {
        return idConductorCamion;
    }

    public void setIdConductorCamion(int idConductorCamion) {
        this.idConductorCamion = idConductorCamion;
    }

    public Camionero getConductor() {
        return conductor;
    }

    public void setConductor(Camionero conductor) {
        this.conductor = conductor;
    }

    public Camion getCamion() {
        return camion;
    }

    public void setCamion(Camion camion) {
        this.camion = camion;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }
    

    // ---------- VALIDACIONES ----------
    private void validarCampos() throws SQLException {
        if (conductor == null || Camionero.buscarPorId(conductor.getIdCamionero()) == null)
            throw new IllegalArgumentException("El camionero indicado no existe.");
        if (camion == null || Camion.buscarPorId(camion.getIdCamion()) == null)
            throw new IllegalArgumentException("El camión indicado no existe.");
        if (fecha == null)
            throw new IllegalArgumentException("La fecha es obligatoria.");
    }

    private void validarDisponibilidad(Connection cn) throws SQLException {
        String sql = "SELECT idCamionero, idCamion FROM conductor_camion "
                   + "WHERE fecha = ? AND idConductorCamion <> ? AND (idCamionero = ? OR idCamion = ?)";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(fecha));
            ps.setInt(2, idConductorCamion);
            ps.setInt(3, conductor.getIdCamionero());
            ps.setInt(4, camion.getIdCamion());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    boolean mismoCamionero = rs.getInt("idCamionero") == conductor.getIdCamionero();
                    boolean mismoCamion = rs.getInt("idCamion") == camion.getIdCamion();
                    if (mismoCamionero && mismoCamion)
                        throw new IllegalArgumentException("Esa asignación ya existe para esa fecha.");
                    if (mismoCamion)
                        throw new IllegalArgumentException("El camión ya está asignado a otro camionero en esa fecha.");
                    throw new IllegalArgumentException("El camionero ya tiene otro camión asignado en esa fecha.");
                }
            }
        }
    }

    // ---------- CRUD ----------
    public void insertar() throws SQLException {
        validarCampos();
        try (Connection cn = Conexion.getConexion()) {
            validarDisponibilidad(cn);
            String sql = "INSERT INTO conductor_camion (idCamionero, idCamion, fecha) VALUES (?,?,?)";
            try (PreparedStatement ps = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, conductor.getIdCamionero());
                ps.setInt(2, camion.getIdCamion());
                ps.setDate(3, Date.valueOf(fecha));
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) idConductorCamion = rs.getInt(1);
                }
            }
        }
    }

    public void actualizar() throws SQLException {
        validarCampos();
        try (Connection cn = Conexion.getConexion()) {
            validarDisponibilidad(cn);
            String sql = "UPDATE conductor_camion SET idCamionero=?, idCamion=?, fecha=? WHERE idConductorCamion=?";
            try (PreparedStatement ps = cn.prepareStatement(sql)) {
                ps.setInt(1, conductor.getIdCamionero());
                ps.setInt(2, camion.getIdCamion());
                ps.setDate(3, Date.valueOf(fecha));
                ps.setInt(4, idConductorCamion);
                if (ps.executeUpdate() == 0)
                    throw new IllegalArgumentException("No existe una asignación con ese ID.");
            }
        }
    }

    public void eliminar() throws SQLException {
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement("DELETE FROM conductor_camion WHERE idConductorCamion=?")) {
            ps.setInt(1, idConductorCamion);
            if (ps.executeUpdate() == 0)
                throw new IllegalArgumentException("No existe una asignación con ese ID.");
        }
    }

    public static List<ConductorCamion> listar() throws SQLException {
        List<ConductorCamion> lista = new ArrayList<>();
        try (Connection cn = Conexion.getConexion();
             Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM conductor_camion ORDER BY idConductorCamion")) {
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    public static ConductorCamion buscarPorId(int id) throws SQLException {
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement("SELECT * FROM conductor_camion WHERE idConductorCamion=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    private static ConductorCamion mapear(ResultSet rs) throws SQLException {
        return new ConductorCamion(rs.getInt("idConductorCamion"),
                Camionero.buscarPorId(rs.getInt("idCamionero")),
                Camion.buscarPorId(rs.getInt("idCamion")),
                rs.getDate("fecha").toLocalDate());
    }

    @Override
    public String toString() {
        return idConductorCamion
                + " | Camionero: " + (conductor != null ? conductor.getNombre() + " " + conductor.getApellidos() : "-")
                + " | Camión: " + (camion != null ? camion.getModelo() + " (" + camion.getNoPlaca() + ")" : "-")
                + " | Fecha: " + fecha;
    }
}