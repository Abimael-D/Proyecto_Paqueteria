/**
 *
 * @author Hermelindo.UMG
 */

package modelo;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import util.Conexion;
import util.Validaciones;

public class Camionero {
    private int idCamionero;
    private String nombre;
    private String apellidos;
    private String direccion;
    private BigDecimal salario;
    private String poblacion;
    private String dpi;
    private String telefono;

    public Camionero() {}

    public Camionero(int idCamionero, String nombre, String apellidos, String direccion,
                     BigDecimal salario, String poblacion, String dpi, String telefono) {
        this.idCamionero = idCamionero;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.direccion = direccion;
        this.salario = salario;
        this.poblacion = poblacion;
        this.dpi = dpi;
        this.telefono = telefono;
    }
    
    //getters and setters

    public int getIdCamionero() {
        return idCamionero;
    }

    public void setIdCamionero(int idCamionero) {
        this.idCamionero = idCamionero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public BigDecimal getSalario() {
        return salario;
    }

    public void setSalario(BigDecimal salario) {
        this.salario = salario;
    }

    public String getPoblacion() {
        return poblacion;
    }

    public void setPoblacion(String poblacion) {
        this.poblacion = poblacion;
    }

    public String getDpi() {
        return dpi;
    }

    public void setDpi(String dpi) {
        this.dpi = dpi;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    
    // ---------- VALIDACIONES ----------
    private void validar() {
        if (Validaciones.vacio(nombre))    throw new IllegalArgumentException("El nombre es obligatorio.");
        if (Validaciones.vacio(apellidos)) throw new IllegalArgumentException("Los apellidos son obligatorios.");
        if (Validaciones.vacio(direccion)) throw new IllegalArgumentException("La dirección es obligatoria.");
        if (Validaciones.vacio(poblacion)) throw new IllegalArgumentException("La población es obligatoria.");
        if (!Validaciones.mayorACero(salario)) throw new IllegalArgumentException("El salario debe ser mayor a 0.");
        if (!Validaciones.esDpi(dpi))      throw new IllegalArgumentException("El DPI debe tener 13 dígitos numéricos.");
        if (!Validaciones.esTelefono(telefono)) throw new IllegalArgumentException("El teléfono debe tener 8 dígitos numéricos.");
    }

    private boolean dpiDuplicado(Connection cn) throws SQLException {
        String sql = "SELECT COUNT(*) FROM camionero WHERE dpi = ? AND idCamionero <> ?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, dpi);
            ps.setInt(2, idCamionero);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }

    private boolean tieneDependencias(Connection cn) throws SQLException {
        String sql = "SELECT (SELECT COUNT(*) FROM paquete WHERE idCamionero = ?) "
                   + "+ (SELECT COUNT(*) FROM conductor_camion WHERE idCamionero = ?)";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, idCamionero);
            ps.setInt(2, idCamionero);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }

    // ---------- CRUD ----------
    public void insertar() throws SQLException {
        validar();
        try (Connection cn = Conexion.getConexion()) {
            if (dpiDuplicado(cn)) throw new IllegalArgumentException("Ya existe un camionero con ese DPI.");
            String sql = "INSERT INTO camionero (nombre, apellidos, direccion, salario, poblacion, dpi, telefono) "
                       + "VALUES (?,?,?,?,?,?,?)";
            try (PreparedStatement ps = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, nombre);
                ps.setString(2, apellidos);
                ps.setString(3, direccion);
                ps.setBigDecimal(4, salario);
                ps.setString(5, poblacion);
                ps.setString(6, dpi);
                ps.setString(7, telefono);
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) idCamionero = rs.getInt(1);
                }
            }
        }
    }

    public void actualizar() throws SQLException {
        validar();
        try (Connection cn = Conexion.getConexion()) {
            if (dpiDuplicado(cn)) throw new IllegalArgumentException("Otro camionero ya tiene ese DPI.");
            String sql = "UPDATE camionero SET nombre=?, apellidos=?, direccion=?, salario=?, "
                       + "poblacion=?, dpi=?, telefono=? WHERE idCamionero=?";
            try (PreparedStatement ps = cn.prepareStatement(sql)) {
                ps.setString(1, nombre);
                ps.setString(2, apellidos);
                ps.setString(3, direccion);
                ps.setBigDecimal(4, salario);
                ps.setString(5, poblacion);
                ps.setString(6, dpi);
                ps.setString(7, telefono);
                ps.setInt(8, idCamionero);
                if (ps.executeUpdate() == 0)
                    throw new IllegalArgumentException("No existe un camionero con ese ID.");
            }
        }
    }

    public void eliminar() throws SQLException {
        try (Connection cn = Conexion.getConexion()) {
            if (tieneDependencias(cn))
                throw new IllegalArgumentException("No se puede eliminar: tiene paquetes o camiones asignados.");
            try (PreparedStatement ps = cn.prepareStatement("DELETE FROM camionero WHERE idCamionero=?")) {
                ps.setInt(1, idCamionero);
                if (ps.executeUpdate() == 0)
                    throw new IllegalArgumentException("No existe un camionero con ese ID.");
            }
        }
    }

    public static List<Camionero> listar() throws SQLException {
        List<Camionero> lista = new ArrayList<>();
        try (Connection cn = Conexion.getConexion();
             Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM camionero ORDER BY idCamionero")) {
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    public static Camionero buscarPorId(int id) throws SQLException {
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement("SELECT * FROM camionero WHERE idCamionero=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    private static Camionero mapear(ResultSet rs) throws SQLException {
        return new Camionero(rs.getInt("idCamionero"), rs.getString("nombre"),
                rs.getString("apellidos"), rs.getString("direccion"), rs.getBigDecimal("salario"),
                rs.getString("poblacion"), rs.getString("dpi"), rs.getString("telefono"));
    }

    @Override
    public String toString() {
        return idCamionero + " | " + nombre + " " + apellidos + " | " + direccion + " | Q" + salario
                + " | " + poblacion + " | DPI: " + dpi + " | Tel: " + telefono;
    }
}