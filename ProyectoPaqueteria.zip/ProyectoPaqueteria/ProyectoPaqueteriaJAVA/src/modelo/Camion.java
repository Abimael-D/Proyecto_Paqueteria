/**
 *
 * @author Hermelindo.UMG
*/
package modelo;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import util.Conexion;
import util.Validaciones;

public class Camion {
    private int idCamion;
    private String modelo;
    private String tipo;
    private BigDecimal potencia;
    private String noPlaca;

    public Camion() {}

    public Camion(int idCamion, String modelo, String tipo, BigDecimal potencia, String noPlaca) {
        this.idCamion = idCamion;
        this.modelo = modelo;
        this.tipo = tipo;
        this.potencia = potencia;
        this.noPlaca = noPlaca;
    }

    //getters and setters

    public int getIdCamion() {
        return idCamion;
    }

    public void setIdCamion(int idCamion) {
        this.idCamion = idCamion;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public BigDecimal getPotencia() {
        return potencia;
    }

    public void setPotencia(BigDecimal potencia) {
        this.potencia = potencia;
    }

    public String getNoPlaca() {
        return noPlaca;
    }

    public void setNoPlaca(String noPlaca) {
        this.noPlaca = noPlaca;
    }
    
    
    // ---------- VALIDACIONES ----------
    private void validar() {
        if (Validaciones.vacio(modelo)) throw new IllegalArgumentException("El modelo es obligatorio.");
        if (Validaciones.vacio(tipo))   throw new IllegalArgumentException("El tipo es obligatorio.");
        if (!Validaciones.mayorACero(potencia)) throw new IllegalArgumentException("La potencia debe ser mayor a 0.");
        if (!Validaciones.esPlaca(noPlaca))
            throw new IllegalArgumentException("La placa debe tener de 5 a 10 caracteres alfanuméricos, sin espacios ni guiones.");
        noPlaca = noPlaca.toUpperCase();
    }

    private boolean placaDuplicada(Connection cn) throws SQLException {
        String sql = "SELECT COUNT(*) FROM camion WHERE noPlaca = ? AND idCamion <> ?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, noPlaca);
            ps.setInt(2, idCamion);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }

    private boolean tieneDependencias(Connection cn) throws SQLException {
        String sql = "SELECT COUNT(*) FROM conductor_camion WHERE idCamion = ?";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, idCamion);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }

    // ---------- CRUD ----------
    public void insertar() throws SQLException {
        validar();
        try (Connection cn = Conexion.getConexion()) {
            if (placaDuplicada(cn)) throw new IllegalArgumentException("Ya existe un camión con esa placa.");
            String sql = "INSERT INTO camion (modelo, tipo, potencia, noPlaca) VALUES (?,?,?,?)";
            try (PreparedStatement ps = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, modelo);
                ps.setString(2, tipo);
                ps.setBigDecimal(3, potencia);
                ps.setString(4, noPlaca);
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) idCamion = rs.getInt(1);
                }
            }
        }
    }

    public void actualizar() throws SQLException {
        validar();
        try (Connection cn = Conexion.getConexion()) {
            if (placaDuplicada(cn)) throw new IllegalArgumentException("Otro camión ya tiene esa placa.");
            String sql = "UPDATE camion SET modelo=?, tipo=?, potencia=?, noPlaca=? WHERE idCamion=?";
            try (PreparedStatement ps = cn.prepareStatement(sql)) {
                ps.setString(1, modelo);
                ps.setString(2, tipo);
                ps.setBigDecimal(3, potencia);
                ps.setString(4, noPlaca);
                ps.setInt(5, idCamion);
                if (ps.executeUpdate() == 0)
                    throw new IllegalArgumentException("No existe un camión con ese ID.");
            }
        }
    }

    public void eliminar() throws SQLException {
        try (Connection cn = Conexion.getConexion()) {
            if (tieneDependencias(cn))
                throw new IllegalArgumentException("No se puede eliminar: el camión está asignado a un camionero.");
            try (PreparedStatement ps = cn.prepareStatement("DELETE FROM camion WHERE idCamion=?")) {
                ps.setInt(1, idCamion);
                if (ps.executeUpdate() == 0)
                    throw new IllegalArgumentException("No existe un camión con ese ID.");
            }
        }
    }

    public static List<Camion> listar() throws SQLException {
        List<Camion> lista = new ArrayList<>();
        try (Connection cn = Conexion.getConexion();
             Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM camion ORDER BY idCamion")) {
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    public static Camion buscarPorId(int id) throws SQLException {
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement("SELECT * FROM camion WHERE idCamion=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    private static Camion mapear(ResultSet rs) throws SQLException {
        return new Camion(rs.getInt("idCamion"), rs.getString("modelo"), rs.getString("tipo"),
                rs.getBigDecimal("potencia"), rs.getString("noPlaca"));
    }

    @Override
    public String toString() {
        return idCamion + " | " + modelo + " | " + tipo + " | " + potencia + " HP | Placa: " + noPlaca;
    }
}